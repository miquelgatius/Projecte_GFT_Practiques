
 var app = angular.module('serviceConsumer', ['ngCookies']);


    app.factory('calchash', function() {
        return {
            S4: function() {
                return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
            }
        };
    });
    
    







 app.controller('questionsController', ['$scope', '$http', '$templateCache','$cookieStore','calchash',
  function($scope, $http, $templateCache,$cookieStore, calchash){
   
       var input = document.getElementById('algo');
       var input2 = document.getElementById('algo2');          
           
           $scope.url ='http://localhost:8080/aak/webresources/funator.usuaris/login/';
           $scope.method = 'GET';
           
           //$scope.nom = SessionUser.name;
           
           
                       $scope.apretar=function(){
                                            
                                var user = input.value;
                                var pass = input2.value;
                                
                                 //SessionUser.name=user;    
                                 
                                    if(input.value.length === 0)
                                      {
                                        input.value = "Introdueix un valor";                                  
                                      }                                      
                                    else
                                      {                                                                                                                                                
                                         $http({method: $scope.method, url: $scope.url+user+'/'+pass, cache: $templateCache}).
                                              success(function(data, status) {                                                   
                                                   
                                           
                                                     $scope.data = data;
                                                     if(data.toString()==='1')
                                                     {
                                                         var hash = (calchash.S4() + calchash.S4() + "-" + calchash.S4() + "-4" + calchash.S4().substr(0,3) + "-" + calchash.S4() + "-" + calchash.S4() + calchash.S4() + calchash.S4()).toLowerCase()+user+"+-+-*--+"+calchash.S4()+"-"+calchash.S4() ;
                                                         $cookieStore.put('myFavorite',user);
                                                         $cookieStore.put('token',hash);
                                                        //window.location= "html.html"; 
                                                        $scope.nom= user;
                                                        $scope.token = hash;
                                                     }
                                                     else
                                                     {
                                                         $scope.nom="NOOOOOOOOOOOOOOOOOO";
                                                     }
                                                     
                                                        })
                                                        
                                               .error(function(error, status){
                                                    input.value="No he entrat";
                                                    $scope.appDetail = error || "Request failed";
                                                        });
                                      }
                        };
            
                   
    }]);
 

var sampleApp = angular.module('sampleApp', []);
 
sampleApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/Inde', {
        templateUrl: 'index.html',
        controller: 'AddOrderController'
    }).
      when('/Htm', {
        templateUrl: 'html.html',
        controller: 'ShowOrdersController'
      }).
      otherwise({
        redirectTo: '/Inde'
      });
}]);
 sampleApp.controller('AddOrderController', function($scope) {    
    $scope.message = 'This is Add new order screen';   
});
sampleApp.controller('ShowOrdersController', function($scope) { 
    $scope.message = 'This is Show orders screen'; 
});




  
app.controller('cookieController', ['$cookieStore', '$scope','$http', '$templateCache', function($cookieStore, $scope,$http,$templateCache) {
  // Put cookie
  
  // Get cookie
  var favoriteCookie = $cookieStore.get('myFavorite');
  $scope.nouu = favoriteCookie;
  
  
}]);

app.controller('even', ['$scope','$http', '$templateCache', function( $scope,$http,$templateCache) {

   $scope.url ='http://localhost:8080/aak/webresources/funator.events';
   $scope.method = 'GET';
   
  $http({method: $scope.method, url: $scope.url, cache: $templateCache}).
                                              success(function(data, status) {                                                                                                     
                                                     $scope.events = data;
                                                        })                                                      
                                               .error(function(error, status){                                                  
                                                    $scope.appDetail = error || "Request failed";
                                                        });
}]);

app.controller('ofer', ['$scope','$http', '$templateCache', function( $scope,$http,$templateCache) {

   $scope.url ='http://localhost:8080/aak/webresources/funator.ofertes';
   $scope.method = 'GET';
   
  $http({method: $scope.method, url: $scope.url, cache: $templateCache}).
                                              success(function(data, status) {                                                                                                     
                                                     $scope.ofertes = data;
                                                        })                                                      
                                               .error(function(error, status){                                                  
                                                    $scope.appDetail = error || "Request failed";
                                                        });
}]);

app.controller('empr', ['$scope','$http', '$templateCache', function( $scope,$http,$templateCache) {

   $scope.url ='http://localhost:8080/aak/webresources/funator.empresa';
   $scope.method = 'GET';
   
  $http({method: $scope.method, url: $scope.url, cache: $templateCache}).
                                              success(function(data, status) {                                                                                                     
                                                     $scope.empreses = data;
                                                        })                                                      
                                               .error(function(error, status){                                                  
                                                    $scope.appDetail = error || "Request failed";
                                                        });
}]);